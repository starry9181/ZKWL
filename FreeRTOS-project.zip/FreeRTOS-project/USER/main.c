
#include "main.h"

void all_driver_init(void);

//�������ȼ�
#define START_TASK_PRIO 1
//�����ջ��С
#define START_STK_SIZE 256
/*********************������***************************/
TimerHandle_t AutoReloadTimer_Handle; //���ڶ�ʱ�����
TaskHandle_t StartTask_Handler;
TaskHandle_t Task1_Handler;
TaskHandle_t Uart_Handler;
/*********************������***************************/
void start_task(void *pvParameters);
void Task1(void *pvParameters);
void Task_Uart(void *pvParameters);
void SendRobotData50MS(TimerHandle_t xTimer);
/*********************main***************************/
int main(void)
{
	PID_struct_init(&pid_position, POSITION_PID, TIM8_Period, TIM8_Period, 1, 0, 0);
	// Temperature_init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	all_driver_init();
	// ������ʼ����
	xTaskCreate((TaskFunction_t)start_task,			 
				(const char *)"start_task",			
				(uint16_t)START_STK_SIZE,			 //
				(void *)NULL,						 //
				(UBaseType_t)START_TASK_PRIO,		 //
				(TaskHandle_t *)&StartTask_Handler); //
	vTaskStartScheduler();
}
void start_task(void *pvParameters)
{
	// CountSemaphore4=xSemaphoreCreateCounting(1,0);
	CountSemaphore2 = xSemaphoreCreateCounting(1, 0);
	taskENTER_CRITICAL(); //进入临界值

	//定时器周期
//	AutoReloadTimer_Handle = xTimerCreate((const char *)"SendRobotData50MS",
//										  (TickType_t)500,
//										  (UBaseType_t)pdTRUE,
//										  (void *)1,
//										  (TimerCallbackFunction_t)SendRobotData50MS); //���ڶ�ʱ��������1s(1000��ʱ�ӽ���)������ģʽ

	xTaskCreate((TaskFunction_t)Task1,
				(const char *)"Task1",
				(uint16_t)128,
				(void *)NULL,
				(UBaseType_t)2,
				(TaskHandle_t *)&Task1_Handler);
	xTaskCreate((TaskFunction_t)Task_Uart,
				(const char *)"Task1",
				(uint16_t)128,
				(void *)NULL,
				(UBaseType_t)2,
				(TaskHandle_t *)&Uart_Handler);

	vTaskDelete(StartTask_Handler); //ɾ����ʼ����
	taskEXIT_CRITICAL();			//退出临界值
}

s16 speed=1200;     //-1182  5018   6200

void Task1(void *pvParameters)
{
	u8 time=0;
//  BeefON(1,10);
	while (1)
	{
		IWDG_FEED();
//		BeefTOON();
		if (com_black_init == 0)
		{
			comeblack();
		}
		if (com_black_init == 1)
		{
			data_collect(&pos_set_get);
			control_temp(&pos_set_get);
			if(time==5)
			{
					feedback_data();
					time=0;
			}
					
		}
    time++;
		vTaskDelay(10);
		
		
	}
}

void Task_Uart(void *pvParameters)
{
	while (1)
	{

		if (com_black_init == 1)
		{
			xSemaphoreTake(CountSemaphore2, portMAX_DELAY); //
			receice_data_robot(USART2_Rx_Buff);
			taskYIELD();
		}
	}
}



void all_driver_init(void)
{
	delay_init();
	Time_Config();
	USART2_Config(115200);
	Temperature_init(); //发热带
	GPIO_INIT(); //蜂鸣器和状态灯
	
	IWDG_init();
	BEEF=1;
  delay_ms(30);
	//vTaskDelay(50);
	BEEF=0;
}
// 50ms上传数据
void SendRobotData50MS(TimerHandle_t xTimer)
{
	feedback_data();
}

