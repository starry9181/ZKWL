#ifndef __MAIN_H
#define __MAIN_H	 
#include "sys.h"
#include <string.h>
#include <stdio.h>
#include "delay.h"
#include "usart.h"

#include "FreeRTOS.h"
#include "task.h"
#include "bsp_usart.h"
#include <math.h>
#include "magnetic.h"
#include "stmflash.h"
#include "buildmap.h"
#include "malloc.h"
#include "timers.h"

#include "flash.h"
#include "motor.h"
#include "encoder.h"
#include "ros_usrt.h"
#include "temperature.h"
#include "control.h"
#include "data_send_receive.h"
#include "./buzzer/buzzer.h"
#include "./iwdg/iwdg.h"








#endif
