#ifndef __USART_TASK_H
#define __USART_TASK_H	 
#include "sys.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
typedef struct
{
	int task1;
	int task2;
	int task3;
	int task4;
	int task5;
	int task6;
	int task7;
	int task8;
	int task9;
	int task10;
}SPACE;
extern SPACE Space;
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void GiveTheSemaphore(u8 *fromdata,u8 aimdata[10][30],SemaphoreHandle_t Cout);


#endif
