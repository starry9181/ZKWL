/**
  ******************************************************************************
  * @file    led.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-12-12
  * @brief   ���������ȿ���
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "usart_task.h"
#include "bsp_usart.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"
#include <stdarg.h>      
#include "magnetic.h"
#include "buildmap.h"
#include <string.h>


