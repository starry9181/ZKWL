#include "data_send_receive.h"
#include "control.h"
#include "ros_usrt.h"
#include "string.h"
#include "stdlib.h"
#include "timers.h"

extern TimerHandle_t AutoReloadTimer_Handle;
static u8 SendDataMode = 0; // 50ms上传模式
union ReciveData RXRobotData;
void receice_data_robot(u8 *data)
{
	u8 i = 0;
	u16 TempCheck = 0;
	for (i = 0; i < sizeof(RXRobotData.data); i++)
	{
		RXRobotData.data[i] = data[i];
	}
	if (RXRobotData.prot.Header == DATAHEAD && RXRobotData.prot.Type == 0x01)
	{
		switch (RXRobotData.prot.Cmd)
		{
//		case 0x00: //反馈升降机的信息(开启或关闭)
//		{
//			for (i = 0; i < sizeof(RXRobotData.data) - 2; i++)
//			{
//				TempCheck += RXRobotData.data[i];
//			}

//			if (TempCheck == RXRobotData.prot.Check)
//			{
//				SendDataMode = RXRobotData.prot.data;
//				if (SendDataMode) //开启50ms上传   0x01
//					xTimerStart(AutoReloadTimer_Handle, 0);
//				// feedback_data();
//				else // 0x00
//					xTimerStop(AutoReloadTimer_Handle, 0);
//			}
//			break;
//		}
		case 0x01: //设置位置
		{
			for (i = 0; i < sizeof(RXRobotData.data) - 2; i++)
			{
				TempCheck += RXRobotData.data[i];
			}

			if (TempCheck == RXRobotData.prot.Check)
			{

				//设置位置的内容
				pos_set_get.ros_set_postion = RXRobotData.prot.data;
			}
			break;
		}
		case 0x02: //温度开关
			for (i = 0; i < sizeof(RXRobotData.data) - 2; i++)
			{
				TempCheck += RXRobotData.data[i];
			}
			if (TempCheck == RXRobotData.prot.Check)
			{
				//设置温度开关
				pos_set_get.ros_temp_state = RXRobotData.prot.data;
			}
		default:
			break;
		}
	}

	// memset(UART5_Rx_Buff, 0, MAX_RX_CNT); // data clear
	// g_UART5_RecPos = 0;
}

//反馈升降机、发热带的信息的内容
union SendHardData TXHardData;
void feedback_data(void)
{
	u8 i = 0;
	u16 TempCheck = 0;
	TXHardData.prot.Header = DATAHEAD;						  //帧头
	TXHardData.prot.Len = 0x07;								  //数据长度
	TXHardData.prot.Type = 0x01;							  //数据类型
	TXHardData.prot.Cmd = 0x80;								  //命令
	TXHardData.prot.Num = 0x02;								  //数据个数
															  //  if(pos_set_get.get_postion<=5978)
															  //	  TXHardData.prot.postion = pos_set_get.get_postion / POS_K; //当前的位置
															  //	else if(pos_set_get.get_postion>5978)
	TXHardData.prot.postion = pos_set_get.get_postion / 12.4; //当前的位置

	TXHardData.prot.temp = !pos_set_get.read_temp; // 0:开   1：关

	TXHardData.prot.Check = 0;
	for (i = 0; i < sizeof(TXHardData.data) - 2; i++)
	{
		TempCheck += TXHardData.data[i];
	}
	TXHardData.prot.Check = TempCheck;

	USART2_DMA_TX(TXHardData.data, sizeof(TXHardData.data));
}
