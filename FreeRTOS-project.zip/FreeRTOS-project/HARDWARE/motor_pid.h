#ifndef _MOTOR_PID_H
#define _MOTOR_PID_H
#include "sys.h"

#define ABS(x)		((x>0)? (x): (-x)) 
void abs_limit(float *a, float ABS_MAX);
enum
{
    LLAST = 0,
    LAST = 1,
    NOW = 2,

    POSITION_PID,
    DELTA_PID,
};
typedef struct __pid_t
{
    float p;
    float i;
    float d;

    float set[3]; //Ŀ��ֵ
    float get[3]; //����ֵ
    float err[3]; //���

    float pout; //pֵ���
    float iout; //iֵ���
    float dout; //dֵ���

    float pos_out;      //λ��ʽ���ֵ
    float last_pos_out; //��һ��λ��ʽ���ֵ
    float delta_u;      //��ǰ����ʽ���ֵ
    float delta_out;    //�ܵ�����ʽ���ֵ = last_delta_out + delta_u
    float last_delta_out;

    float max_err;
    float deadband; //err < deadband return
    uint32_t pid_mode;
    uint32_t MaxOutput;     //������ֵ
    uint32_t IntegralLimit; //��������

    void (*f_param_init)(struct __pid_t *pid, //PID��ʼ��
                         uint32_t pid_mode,
                         uint32_t maxOutput,
                         uint32_t integralLimit,
                         float p,
                         float i,
                         float d);
    void (*f_pid_reset)(struct __pid_t *pid, float p, float i, float d); //pid ����

} pid_t;



void PID_struct_init(
    pid_t* pid,
    uint32_t mode,
    uint32_t maxout,
    uint32_t intergral_limit,
    
    float 	kp, 
    float 	ki, 
    float 	kd);
float current_calc_pid(pid_t* pid, float get, float set);
extern pid_t pid_position;














#endif


