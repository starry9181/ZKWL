#ifndef _TEMPERATURE_H
#define _TEMPERATURE_H
#include "sys.h"


#define GPIO_TEMP  GPIOB
#define GPIO_Pin_TEMP GPIO_Pin_0
#define TEMP  PBout(0)      //

#define CLOSE_TEMP   1
#define OPEN_TEMP    0

void Temperature_init(void);













#endif
