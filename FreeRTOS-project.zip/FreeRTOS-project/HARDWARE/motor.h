#ifndef _MOTOR_H
#define _MOTOR_H
#include "sys.h"

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--------------------------------------定时器引脚图---------------------------------------------------
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/ 
#define TIM8_Period 1200
/*++++++++++++++++++++++++++++++++++TIME1_ENCODER+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM1_ENCODER_TIM_CLK  	RCC_APB2Periph_TIM1
#define TIM1_ENCODER_PIN_CLK	RCC_APB2Periph_GPIOA
#define TIM1_ENCODER_PIN        GPIO_Pin_8|GPIO_Pin_9
#define TIM1_ENCODER_PORT       GPIOA

/*++++++++++++++++++++++++++++++++++TIME2_ENCODER+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM2_ENCODER_TIM_CLK  	RCC_APB1Periph_TIM2
#define TIM2_ENCODER_PIN_CLK	RCC_APB2Periph_GPIOA 
#define TIM2_ENCODER_PIN_CLK1	RCC_APB2Periph_GPIOB
#define TIM2_ENCODER_PIN        GPIO_Pin_15
#define TIM2_ENCODER_PIN1  		GPIO_Pin_3
#define TIM2_ENCODER_PORT       GPIOA
#define TIM2_ENCODER_PORT1      GPIOB

/*++++++++++++++++++++++++++++++++++TIME3_PWM+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM3_PWM_TIM_CLK  		RCC_APB1Periph_TIM3
#define TIM3_PWM_PIN_CLK		RCC_APB2Periph_GPIOA
#define TIM3_PWM_PIN       		GPIO_Pin_6|GPIO_Pin_7
#define TIM3_PWM_PORT       	GPIOA

/*++++++++++++++++++++++++++++++++++TIME3_ENCODER+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM3_ENCODER_TIM_CLK  	RCC_APB1Periph_TIM3
#define TIM3_ENCODER_PIN_CLK	RCC_APB2Periph_GPIOA
#define TIM3_ENCODER_PIN        GPIO_Pin_6|GPIO_Pin_7
#define TIM3_ENCODER_PORT       GPIOA

/*++++++++++++++++++++++++++++++++++TIME4_PWM+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM4_PWM_TIM_CLK  		RCC_APB1Periph_TIM4
#define TIM4_PWM_PIN_CLK		RCC_APB2Periph_GPIOB
#define TIM4_PWM_PIN        	GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8//|GPIO_Pin_9
#define TIM4_PWM_PORT       	GPIOB

/*++++++++++++++++++++++++++++++++++TIME4_ENCODER+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM4_ENCODER_TIM_CLK  	RCC_APB1Periph_TIM4
#define TIM4_ENCODER_PIN_CLK	RCC_APB2Periph_GPIOB
#define TIM4_ENCODER_PIN        GPIO_Pin_6|GPIO_Pin_7
#define TIM4_ENCODER_PORT       GPIOB

/*++++++++++++++++++++++++++++++++++TIME5_ENCODER+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM5_ENCODER_TIM_CLK  	RCC_APB1Periph_TIM5
#define TIM5_ENCODER_PIN_CLK	RCC_APB2Periph_GPIOA
#define TIM5_ENCODER_PIN        GPIO_Pin_0|GPIO_Pin_1
#define TIM5_ENCODER_PORT       GPIOA

/*++++++++++++++++++++++++++++++++++TIME8_PWM+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define TIM8_PWM_TIM_CLK  		RCC_APB2Periph_TIM8
#define TIM8_PWM_PIN_CLK		RCC_APB2Periph_GPIOC
#define TIM8_PWM_PIN        	GPIO_Pin_6|GPIO_Pin_8|GPIO_Pin_9//GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9
#define TIM8_PWM_PORT       	GPIOC

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define EncoderPeriod  0xffff//20000

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void Time_Config(void);
void TIM1_Configuration(void);//编码器接口设置TIM1/PA8-B相  PA9-A相










#endif 
