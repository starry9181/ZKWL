#ifndef __BULDMAP_H
#define __BULDMAP_H	 
#include "sys.h"
//////////////////////////////////////////////////////////////////////////////////	 								  
//////////////////////////////////////////////////////////////////////////////////   	 
#define EMPTY_NODE 0
#define TRUE 1
#define FALSE 0
#define STACK_EMPTY TRUE
#define STACK_NOT_EMPTY FALSE
#define FOUND TRUE
#define NOT_FOUND FALSE
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define PrintMap	u4_printf
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
struct binary_tree 
{
    char data    ;   // Data area
    struct binary_tree * left;
	struct binary_tree * middl;
    struct binary_tree * right;
}; 
typedef struct binary_tree node;
// ����������
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

//�ر�����Ϣ
typedef struct
{
	u8 left;	//��ת�ر�
	u8 middl;	//ֱ�еر�
	u8 right;	//��ת�ر�
	
}POINT;

extern POINT Point[50];
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

//�ر�����
typedef struct
{
	u16 x;		//����X
	u16 y;		//����y
	int dic;		//����
	u8 num;		//�ر��
	u8 tree;	//֧����1��2
}XYPOINT;

//�ر궯��
typedef struct
{
	u8 Land;	//�ر�
	u8 Action;	//����
}LANDACTION;
extern LANDACTION LandAction[20];
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//XYPOINT XYPoint,FirsLR[10];
extern u8 TwoForkTreeData[100];
extern int Creatnum;//�������������
extern u8 result[50];

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

void Creatnode(node ** tree,u8 *val);
_Bool pathFromNode(node *rootNode, u8 nodeA, u8 nodeB);
void deltree(node * tree);
void SendPoint(void);
void SetPoint(u8 *data);
void GetHidiData(u8 *data);
node *searchTheNode(node * tree, int value);
void Goway(node *rootNode,u8 *data);
//·�����ɴ�ӡ
void TheWayGenerate(u8 *data);


void WayRule(void);
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#endif
