#include "flash.h"



void FLASH_WriteHalfWord(u32 add, u16 *DataBuf, u16 number)
{
	volatile FLASH_Status FLASHStatus;

	FLASH_Unlock();//����                
	FLASHStatus = FLASH_COMPLETE;  
	FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);//�����־λ
	FLASHStatus = FLASH_ErasePage(add);    //����ָ����ַҳ     
	FLASH_Unlock();         
	while(number)
	{
		FLASH_ProgramHalfWord(add, *DataBuf);//��ָ���ĵ�ַ��ʼд��
		if(FLASH_GetStatus()==FLASH_COMPLETE)  
		{
			number--;
			add += 2;
			DataBuf++;
		}
		else 
		{
				number=0;
		}
	} 
	FLASH_Lock();//����
}

void FLASH_ReadHalfWord(u32 add, u16 *DataBuf, u16 number)
{
	u8 i;
	for(i = 0;i < number;i++)
	{
		DataBuf[i] = *(__IO uint32_t*)add;
		add += 2;
	}
}
#define SIZE sizeof(TEXT_Buffer)                  ///���鳤��
#define FLASH_SAVE_ADDR  0X08070000   //����FLASH �����ַ(����Ϊż��������ֵҪ���ڱ�������ռ��FLASH�Ĵ�С+0X08000000)
u8 TEXT_Buffer[]={"STM32 FLASH TEST"};
u8 datatemp[SIZE];

#define diaodian 1
void data_flash(void)
{
if(diaodian)//�жϵ���
{
FLASH_WriteHalfWord(FLASH_SAVE_ADDR,(u16*)TEXT_Buffer,SIZE);//flashд����
}  
FLASH_ReadHalfWord(FLASH_SAVE_ADDR,(u16*)datatemp,SIZE);     //flash������ 

}
















//void  PVD_IRQHandler(void)
//{
//  

////   if(PWR_GetFlagStatus(PWR_FLAG_PVDO))
////   {
////      MSD0_WriteSingleBlock(1, buf);
////   }

//   EXTI_ClearITPendingBit(EXTI_Line16);
//}

//void PVD_Init(void)
//{
//   EXTI_InitTypeDef EXTI_InitStructure;
//   NVIC_InitTypeDef NVIC_InitStructure;

//   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
//   NVIC_InitStructure.NVIC_IRQChannel = PVD_IRQn;
//   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//   NVIC_Init(&NVIC_InitStructure);

//   RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);

//   PWR_PVDLevelConfig(PWR_PVDLevel_2V9);	//�����÷�Χ��2.2-2.9V
//   PWR_PVDCmd(ENABLE);

//   EXTI_DeInit();
//   EXTI_StructInit(&EXTI_InitStructure);
//   EXTI_InitStructure.EXTI_Line = EXTI_Line16;	//PVD���ӵ��ⲿ�ж�16
//   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//   EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
//   EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//   EXTI_Init(&EXTI_InitStructure);
//}





