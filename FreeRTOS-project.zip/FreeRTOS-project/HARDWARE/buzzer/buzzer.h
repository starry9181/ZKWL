#ifndef _BUZZER_H
#define _BUZZER_H
#include "sys.h"

#define BEEF PAout(10)

typedef struct
{
	u8 cnt;//响声次数
	u16 Time;//响声间隔
	u8 Flag;
}BEEFTOON;

void BeefON(u8 cnt,u16 time);
void BeefTOON(void);
void GPIO_INIT(void);







#endif




