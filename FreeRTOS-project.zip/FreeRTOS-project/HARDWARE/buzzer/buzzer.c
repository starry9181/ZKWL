#include "./buzzer/buzzer.h"
#include "control.h"
//蜂鸣器  、  方向  、电流
static void buzzer_gpio_init(void)
{
	GPIO_InitTypeDef GPIO_Typedef_init;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC, ENABLE); //使能GPIO外设时钟使能

	GPIO_Typedef_init.GPIO_Pin = GPIO_Pin_10;
	GPIO_Typedef_init.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Typedef_init.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOA, &GPIO_Typedef_init);

	GPIO_Typedef_init.GPIO_Pin = GPIO_Pin_14;
	GPIO_Typedef_init.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Typedef_init.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOC, &GPIO_Typedef_init);
	DERCTION = 1;

	GPIO_Typedef_init.GPIO_Pin = GPIO_Pin_3;
	GPIO_Typedef_init.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Typedef_init.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOC, &GPIO_Typedef_init);
	
	BEEF = 0;
}
//状态灯
static void state_led_init(void)
{
	GPIO_InitTypeDef GPIO_Typedef_init;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE); //使能GPIO外设时钟使能

	GPIO_Typedef_init.GPIO_Pin = GPIO_Pin_13;
	GPIO_Typedef_init.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Typedef_init.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOC, &GPIO_Typedef_init);
	
}

void GPIO_INIT(void)
{
	buzzer_gpio_init();
	state_led_init();
}

BEEFTOON BeefToOn;
void BeefON(u8 cnt, u16 time)
{
	BeefToOn.cnt = cnt;
	BeefToOn.Time = time / 100;
	BeefToOn.Flag = 1;
}

/*******************************************************
 * Function Name  : BeefTOON
 * Description    : 蜂鸣器主循环
 * Input          : None
 * Output         : None
 * Return         : None
 *********************************************************/
void BeefTOON(void)
{
	static u8 BeefStep = 0, TimeCnt = 0;
	if (BeefToOn.Flag)
	{
		TimeCnt++;
		if (TimeCnt < BeefToOn.Time)
		{
			return;
		}
		TimeCnt = 0;
		switch (BeefStep)
		{
		case 0:
		{
			if (BeefToOn.cnt--)
			{
				BEEF = 1;
				BeefStep = 1;
			}
			else
			{
				BEEF = 0;
				BeefToOn.Flag = 0;
				BeefStep = 0;
			}
			break;
		}
		case 1:
		{
			BEEF = 0;
			BeefStep = 0;
			break;
		}
		}
	}
	else
	{
		TimeCnt = 0;
	}
}
