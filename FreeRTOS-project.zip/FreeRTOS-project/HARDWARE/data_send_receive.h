#ifndef _DATA_SEND_RECEIVE_H
#define _DATA_SEND_RECEIVE_H
#include "sys.h"
#define	DATAHEAD    0xDEED //数据头
/*+++++++++++++++++++++++++++++++++++++++++接收上位机数据++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
extern union ReciveData
{
	u8 data[10];
	struct
	{
		u16 Header;			//帧头
		u8  Len;			//帧长
		u8  Type;			//类型
		u8  Cmd;			//帧命令
		u8  Num;			//命令个数
		u16 data;		    //数据
		u16 Check;			//校验
	}prot;
}RXReciveData;

/*+++++++++++++++++++++++++++++++++++++++++返回信息++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
extern union SendHardData
{
	u8 data[12];
	struct
	{
		u16 Header;			//帧头
		u8  Len;			//帧长
		u8  Type;			//类型
		u8  Cmd;			//帧命令
		u8  Num;			//命令个数
			u16 postion;        //位置
			u16 temp;            //发热带状态
		u16  Check;			//校验
	}prot;
}TXRobotHardData;







void receice_data_robot(u8 *data);
void feedback_data(void);

#endif
