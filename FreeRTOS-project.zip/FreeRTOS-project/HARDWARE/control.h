#ifndef _CONTROL_H
#define _CONTROL_H
#include "sys.h"
#include "motor_pid.h"
#define DERCTION PCout(14) //方向
#define STOPPWM 10

#define DERCTION_PWM TIM8->CCR1
#define POS_K 12.2 // 脉冲数对应的高度   hight*POS_K = 编码数

typedef struct
{
    int32_t set_postion; //设置目标值
    int32_t get_postion; //当前值

    int32_t ros_set_postion; //上位机设置的高度；
    u8 temp_state;           //发热带状态（0：关闭；1开启）
    u8 ros_temp_state;       //上位机设置的温度状态
    u8 read_temp;            //读取pb0 IO 口的状态
} pos_temp;

void pos_calc_control(pid_t *pos_pid, pos_temp *pos_set);
void pos_control(pos_temp *pos_set);

void set_pwm_direction(s16 pwm);
void data_collect(pos_temp *pos_set); //数据收集
void control_temp(pos_temp *set_temp);
void comeblack(void);
extern pos_temp pos_set_get;
extern u8 com_black_init;
#endif
