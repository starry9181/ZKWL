#include "control.h"
#include "encoder.h"
#include "temperature.h"
#include "delay.h"
#include "FreeRTOS.h"
#include "task.h"
pos_temp pos_set_get;

void set_pwm_direction(s16 pwm)
{
	if (pwm > 0)
	{
		if (pwm < STOPPWM)
		{
			pwm = STOPPWM;
		}
		else
		{
			DERCTION = 1;
		}
	}
	else if (pwm < 0)
	{
		if (pwm > -STOPPWM)
		{
			pwm = -STOPPWM;
		}
		else
		{
			DERCTION = 0;
		}
		pwm = -pwm;
	}
	DERCTION_PWM = pwm;
}

void data_collect(pos_temp *pos_set) //数据收集
{
	pos_set->get_postion = GetEncoder.CNT1;
	//	if(pos_set->ros_set_postion<=490)
	//			pos_set->set_postion = pos_set->ros_set_postion * POS_K;
	//	else if(pos_set->ros_set_postion>490)
	pos_set->set_postion = pos_set->ros_set_postion * 12.4;
	pos_set->temp_state = pos_set->ros_temp_state;
	pos_set->read_temp =  GPIO_ReadOutputDataBit(GPIO_TEMP,GPIO_Pin_TEMP);
}
//测试，未使用pid
void pos_control(pos_temp *pos_set)
{
	if (pos_set->get_postion > pos_set->set_postion)
		set_pwm_direction(-(TIM8_Period));
	else if (pos_set->get_postion < pos_set->set_postion)
		set_pwm_direction((TIM8_Period));

	else if (pos_set->get_postion == pos_set->set_postion)
		set_pwm_direction(0);
}

//使用位置pid计算
void pos_calc_control(pid_t *pos_pid, pos_temp *pos_set)
{
	// pid初始化
	//	PID_struct_init(pos_pid,POSITION_PID,TIM8_Period,TIM8_Period,10,0,0);
	//计算
	current_calc_pid(pos_pid, pos_set->get_postion, pos_set->set_postion);
	if (pos_pid->pos_out >= 5)
		pos_pid->pos_out = 1200;
	else if (pos_pid->pos_out < 5 && pos_pid->pos_out > -5)
		pos_pid->pos_out = 0;
	else if (pos_pid->pos_out <= -5)
		pos_pid->pos_out = -1200;
	set_pwm_direction(pos_pid->pos_out);
}

/*************************启动时升降机回归到0位置**********************/
//上电执行一次
u8 com_black_init = 0;
void comeblack(void)
{
	//反转
	u8 flag = 0;
	set_pwm_direction(-1200);
	if (flag == 0)
	{
		//delay_ms(300);
		vTaskDelay(500);
		flag = 1;
	}
	if (GetEncoder.V1 == 0) //当检测到速度为0时，表示已经归位
	{
		//			set_pwm_direction(0);
		TIM1_Configuration(); //重新初始化
		TIM1->CNT = 0;
		GetEncoder.CNT1 = GetEncoder.CNT1 - GetEncoder.CNT1;
		GetEncoder.cnt1 = GetEncoder.cnt1 - GetEncoder.cnt1;
		GetEncoder.rcnt1 = GetEncoder.rcnt1 - GetEncoder.rcnt1;
		if (flag == 1)
		{
			//delay_ms(1000);
			vTaskDelay(50);
			flag = 2; //延时1秒后再开启串口功能等其他功能
			com_black_init = 1;
		}
	}
}

//温度控制开关
void control_temp(pos_temp *set_temp)
{
	if (set_temp->temp_state == 0)
	{
		TEMP = CLOSE_TEMP; //关闭
	}
	else if (set_temp->temp_state == 1)
	{
		TEMP = OPEN_TEMP; //开启
	}
}
