#include "ros_usrt.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include <string.h>
#include "stm32f10x_dma.h"

#include <stdarg.h>
#include "magnetic.h"
#include "buildmap.h"
#include "semphr.h"
#include "control.h"
#include "temperature.h"

SemaphoreHandle_t CountSemaphore4; //计数型信号量
SemaphoreHandle_t CountSemaphore5; //计数型信号量
SemaphoreHandle_t CountSemaphore3;
SemaphoreHandle_t CountSemaphore2;
#if USART1_DEBUG
//----------------------------- 串口1-------------------------------------------
u8 USART1_Rx_Buff[MAX_RX_CNT];
static u8 USART1_Tx_Buff[MAX_RX_CNT];
//串口2DMA发送 DMA1 通道7
uint8_t USART1_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt)
{
    DMA_Cmd(DMA1_Channel4, DISABLE);

    if (Byte_Cnt > (sizeof(USART1_Tx_Buff) / sizeof(*USART1_Tx_Buff)))
    {
        return 0;
    }

    memcpy(USART1_Tx_Buff, TxBuff, Byte_Cnt);
    DMA_SetCurrDataCounter(DMA1_Channel4, Byte_Cnt);
    DMA_Cmd(DMA1_Channel4, ENABLE);
    return 1;
}
static void USART1_DMA_Config(void)
{
    DMA_InitTypeDef dma_init;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA1_Channel4);
    DMA_DeInit(DMA1_Channel5);

    dma_init.DMA_PeripheralBaseAddr = (uint32_t) & (USART1->DR);
    dma_init.DMA_MemoryBaseAddr = (uint32_t)USART1_Rx_Buff;
    dma_init.DMA_DIR = DMA_DIR_PeripheralSRC;
    dma_init.DMA_BufferSize = MAX_RX_CNT;
    dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    dma_init.DMA_Mode = DMA_Mode_Normal;
    dma_init.DMA_Priority = DMA_Priority_VeryHigh;
    dma_init.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel5, &dma_init);
    DMA_Cmd(DMA1_Channel5, ENABLE);

    dma_init.DMA_PeripheralBaseAddr = (uint32_t) & (USART1->DR);
    dma_init.DMA_MemoryBaseAddr = (uint32_t)USART1_Tx_Buff;
    dma_init.DMA_DIR = DMA_DIR_PeripheralDST;
    dma_init.DMA_BufferSize = 9;
    dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    dma_init.DMA_Mode = DMA_Mode_Normal;
    dma_init.DMA_Priority = DMA_Priority_Medium;
    dma_init.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel4, &dma_init);
    //  DMA_Cmd (DMA1_Channel7,ENABLE);//传输的时候再开启
    USART_DMACmd(USART1, USART_DMAReq_Rx, ENABLE);
    USART_DMACmd(USART1, USART_DMAReq_Tx, ENABLE);
}
static void USART1_NVIC_Config(void)
{
    NVIC_InitTypeDef usart_nvic_init;

    usart_nvic_init.NVIC_IRQChannel = DMA1_Channel5_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 1;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);

    usart_nvic_init.NVIC_IRQChannel = USART1_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 7;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 1;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);
}

void USART1_Config(uint32_t BaudRate)
{
    GPIO_InitTypeDef gpio_init;
    USART_InitTypeDef usart_init;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

    gpio_init.GPIO_Pin = GPIO_Pin_9;
    gpio_init.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio_init);

    gpio_init.GPIO_Pin = GPIO_Pin_10;
    gpio_init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpio_init);

    usart_init.USART_BaudRate = BaudRate;
    usart_init.USART_WordLength = USART_WordLength_8b;
    usart_init.USART_StopBits = USART_StopBits_1;
    usart_init.USART_Parity = USART_Parity_No;
    usart_init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &usart_init);

    USART1_NVIC_Config();
    USART1_DMA_Config();

    USART_ITConfig(USART1, USART_IT_IDLE, ENABLE);
    USART_Cmd(USART1, ENABLE);
    USART_ClearFlag(USART1, USART_FLAG_TC);
}

/********串口1空闲中断函数*******/
/*
void USART1_IRQHandler(void)
{
    BaseType_t   pxHigherPriorityTaskWoken = pdFALSE;
    if(USART_GetITStatus(USART1, USART_IT_IDLE) != RESET)
    {
        uint8_t temp;
        temp = USART1->SR;
        temp = USART1->DR;
        //去警告
        temp=temp;

        DMA_Cmd (DMA1_Channel5,DISABLE);
//		GetMagneticData(USART1_Rx_Buff);

        xSemaphoreGiveFromISR(CountSemaphore1,&pxHigherPriorityTaskWoken);//释放计数型信号量

        DMA_SetCurrDataCounter(DMA1_Channel5,MAX_RX_CNT);
        DMA_Cmd (DMA1_Channel5,ENABLE);
        USART_ClearFlag(USART1, USART_IT_IDLE);
    }
}
*/
/**********DMA1通道6接收中断****/
/*
void DMA1_Channel5_IRQHandler(void)
{
    if(DMA_GetFlagStatus(DMA1_FLAG_TC5)!=RESET)
    {
        DMA_ClearITPendingBit(DMA1_IT_TC5);
    }
}
*/
/*
 *******************************************************************************
 *		DMA	printf
 *******************************************************************************
 */

void u1_printf(const char *format, ...)
{
    uint32_t length;
    char _dbg_TXBuff[100] = {0};
    va_list args;
    va_start(args, format);
    length = vsnprintf((char *)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char *)format, args);
    va_end(args);
    USART1_DMA_TX((const unsigned char *)_dbg_TXBuff, length);
}
#endif

#if USART2_DEBUG

//----------------------------- 串口2-------------------------------------------
u8 USART2_Rx_Buff[MAX_RX_CNT];
// static u8 USART2_Tx_Buff[MAX_RX_CNT];

/*
//串口2DMA发送 DMA1 通道7
uint8_t USART2_DMA_TX(const uint8_t *TxBuff , uint8_t Byte_Cnt)
{
    DMA_Cmd(DMA1_Channel7, DISABLE);

    if(Byte_Cnt>(sizeof(USART2_Tx_Buff)/sizeof(*USART2_Tx_Buff))){return 0;}

    memcpy(USART2_Tx_Buff,TxBuff,Byte_Cnt);
    DMA_SetCurrDataCounter(DMA1_Channel7,Byte_Cnt);
    DMA_Cmd(DMA1_Channel7, ENABLE);

    return 1;
}
*/
uint8_t USART2_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt)
{
    u8 i = 0;
    while (i < Byte_Cnt)
    {
        USART_SendData(USART2, (u8)TxBuff[i++]);
        while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
            ;
    }

    return 1;
}

static void USART2_DMA_Config(void)
{
    DMA_InitTypeDef dma_init;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA1_Channel6);
    DMA_DeInit(DMA1_Channel7);

    dma_init.DMA_PeripheralBaseAddr = (uint32_t) & (USART2->DR);
    dma_init.DMA_MemoryBaseAddr = (uint32_t)USART2_Rx_Buff;
    dma_init.DMA_DIR = DMA_DIR_PeripheralSRC;
    dma_init.DMA_BufferSize = MAX_RX_CNT;
    dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    dma_init.DMA_Mode = DMA_Mode_Normal;
    dma_init.DMA_Priority = DMA_Priority_VeryHigh;
    dma_init.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel6, &dma_init);
    DMA_Cmd(DMA1_Channel6, ENABLE);

    //	dma_init.DMA_PeripheralBaseAddr = (uint32_t)&(USART2->DR);
    //	dma_init.DMA_MemoryBaseAddr = (uint32_t)USART2_Tx_Buff;
    //	dma_init.DMA_DIR = DMA_DIR_PeripheralDST ;
    //	dma_init.DMA_BufferSize = 9;
    //	dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    //	dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    //	dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    //	dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    //	dma_init.DMA_Mode = DMA_Mode_Normal ;
    //	dma_init.DMA_Priority = DMA_Priority_Medium;
    //	dma_init.DMA_M2M = DMA_M2M_Disable;
    //	DMA_Init(DMA1_Channel7, &dma_init);
    //  DMA_Cmd (DMA1_Channel7,ENABLE);//传输的时候再开启

    USART_DMACmd(USART2, USART_DMAReq_Rx, ENABLE);
    //	USART_DMACmd(USART2, USART_DMAReq_Tx, ENABLE);
}

static void USART2_NVIC_Config(void)
{
    NVIC_InitTypeDef usart_nvic_init;

    usart_nvic_init.NVIC_IRQChannel = DMA1_Channel6_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 1;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);

    usart_nvic_init.NVIC_IRQChannel = USART2_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 7;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 2;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);
}

void USART2_Config(uint32_t BaudRate)
{
    GPIO_InitTypeDef gpio_init;
    USART_InitTypeDef usart_init;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

    gpio_init.GPIO_Pin = GPIO_Pin_2;
    gpio_init.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio_init);

    gpio_init.GPIO_Pin = GPIO_Pin_3;
    gpio_init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpio_init);

    usart_init.USART_BaudRate = BaudRate;
    usart_init.USART_WordLength = USART_WordLength_8b;
    usart_init.USART_StopBits = USART_StopBits_1;
    usart_init.USART_Parity = USART_Parity_No;
    usart_init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &usart_init);

    USART2_NVIC_Config();
    USART2_DMA_Config();

    USART_ITConfig(USART2, USART_IT_IDLE, ENABLE);
    USART_Cmd(USART2, ENABLE);
    USART_ClearFlag(USART2, USART_FLAG_TC);
}

/********串口2空闲中断函数*******/
void USART2_IRQHandler(void)
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (USART_GetITStatus(USART2, USART_IT_IDLE) != RESET)
    {
        uint8_t temp;
        temp = USART2->SR;
        temp = USART2->DR;
        //去警告
        temp = temp;
        DMA_Cmd(DMA1_Channel6, DISABLE);

        xSemaphoreGiveFromISR(CountSemaphore2, &pxHigherPriorityTaskWoken); //释放计数型信号量

        DMA_SetCurrDataCounter(DMA1_Channel6, MAX_RX_CNT);
        DMA_Cmd(DMA1_Channel6, ENABLE);
        USART_ClearFlag(USART2, USART_IT_IDLE);
    }
    else
    {
        set_pwm_direction(0);
        TEMP = CLOSE_TEMP; //关闭
    }
}

/**********DMA1通道6接收中断****/
void DMA1_Channel6_IRQHandler(void)
{
    if (DMA_GetFlagStatus(DMA1_FLAG_TC6) != RESET)
    {
        DMA_ClearITPendingBit(DMA1_IT_TC6);
    }
}

/*
 *******************************************************************************
 *		DMA	printf
 *******************************************************************************
 */

/*
void u2_printf(const char *format,...)
{
    uint32_t length;
    char _dbg_TXBuff[100]={0};
    va_list args;
    va_start(args, format);
    length = vsnprintf((char*)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char*)format, args);
    va_end(args);
    USART2_DMA_TX((const unsigned char*)_dbg_TXBuff,length);

}*/

//不带DMA发送
#define CMD_BUFFER_LEN 50
void u2_printf(const char *format, ...)
{
    u8 i = 0;
    uint32_t length;
    char _dbg_TXBuff[CMD_BUFFER_LEN] = {0};
    va_list args;
    taskENTER_CRITICAL(); //进入临界区
    va_start(args, format);
    length = vsnprintf((char *)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char *)format, args);

    while (i < length)
    {
        USART_SendData(USART2, (u8)_dbg_TXBuff[i++]);
        while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
            ;
    }
    va_end(args);
    taskEXIT_CRITICAL(); //退出临界区
}
#endif

#if USART3_DEBUG
//-----------------------------串口 3--------------------------------------------------------
u8 USART3_Rx_Buff[MAX_RX_CNT];
u8 USART3_Tx_Buff[MAX_RX_CNT];

//串口2DMA发送 DMA1 通道7
uint8_t USART3_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt)
{
    DMA_Cmd(DMA1_Channel2, DISABLE);
    if (Byte_Cnt > (sizeof(USART3_Tx_Buff) / sizeof(*USART3_Tx_Buff)))
    {
        return 0;
    }
    memcpy(USART3_Tx_Buff, TxBuff, Byte_Cnt);
    DMA_SetCurrDataCounter(DMA1_Channel2, Byte_Cnt);
    DMA_Cmd(DMA1_Channel2, ENABLE);
    return 1;
}

static void USART3_DMA_Config(void)
{
    DMA_InitTypeDef dma_init;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA1_Channel2);
    DMA_DeInit(DMA1_Channel3);

    dma_init.DMA_PeripheralBaseAddr = (uint32_t) & (USART3->DR);
    dma_init.DMA_MemoryBaseAddr = (uint32_t)USART3_Rx_Buff;
    dma_init.DMA_DIR = DMA_DIR_PeripheralSRC;
    dma_init.DMA_BufferSize = MAX_RX_CNT;
    dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    dma_init.DMA_Mode = DMA_Mode_Normal;
    dma_init.DMA_Priority = DMA_Priority_VeryHigh;
    dma_init.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel3, &dma_init);
    DMA_Cmd(DMA1_Channel3, ENABLE);

    dma_init.DMA_PeripheralBaseAddr = (uint32_t) & (USART3->DR);
    dma_init.DMA_MemoryBaseAddr = (uint32_t)USART3_Tx_Buff;
    dma_init.DMA_DIR = DMA_DIR_PeripheralDST;
    dma_init.DMA_BufferSize = 8;
    dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    dma_init.DMA_Mode = DMA_Mode_Normal;
    dma_init.DMA_Priority = DMA_Priority_Medium;
    dma_init.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel2, &dma_init);
    //  DMA_Cmd (DMA1_Channel7,ENABLE);//传输的时候再开启

    USART_DMACmd(USART3, USART_DMAReq_Rx, ENABLE);
    USART_DMACmd(USART3, USART_DMAReq_Tx, ENABLE);
}

static void USART3_NVIC_Config(void)
{
    NVIC_InitTypeDef usart_nvic_init;

    usart_nvic_init.NVIC_IRQChannel = DMA1_Channel3_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 1;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);

    usart_nvic_init.NVIC_IRQChannel = USART3_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 7;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 3;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);
}

void USART3_Config(uint32_t BaudRate)
{
    GPIO_InitTypeDef gpio_init;
    USART_InitTypeDef usart_init;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);

    gpio_init.GPIO_Pin = GPIO_Pin_10;
    gpio_init.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio_init);

    gpio_init.GPIO_Pin = GPIO_Pin_11;
    gpio_init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &gpio_init);

    usart_init.USART_BaudRate = BaudRate;
    usart_init.USART_WordLength = USART_WordLength_8b;
    usart_init.USART_StopBits = USART_StopBits_1;
    usart_init.USART_Parity = USART_Parity_No;
    usart_init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART3, &usart_init);

    USART3_NVIC_Config();
    USART3_DMA_Config();

    USART_ITConfig(USART3, USART_IT_IDLE, ENABLE);
    USART_Cmd(USART3, ENABLE);
    USART_ClearFlag(USART3, USART_FLAG_TC);
}

/********串口3空闲中断函数*******/
void USART3_IRQHandler(void)
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (USART_GetITStatus(USART3, USART_IT_IDLE) != RESET)
    {
        uint8_t temp;
        temp = USART3->SR;
        temp = USART3->DR;
        //去警告
        temp = temp;
        DMA_Cmd(DMA1_Channel3, DISABLE);

        xSemaphoreGiveFromISR(CountSemaphore3, &pxHigherPriorityTaskWoken); //释放计数型信号量

        DMA_SetCurrDataCounter(DMA1_Channel3, MAX_RX_CNT);
        DMA_Cmd(DMA1_Channel3, ENABLE);
        USART_ClearFlag(USART3, USART_IT_IDLE);
    }
}

/**********DMA1通道6接收中断****/
void DMA1_Channel3_IRQHandler(void)
{
    if (DMA_GetFlagStatus(DMA1_FLAG_TC3) != RESET)
    {
        DMA_ClearITPendingBit(DMA1_IT_TC3);
    }
}

/*
 *******************************************************************************
 *		DMA	printf
 *******************************************************************************
 */

void u3_printf(const char *format, ...)
{
    uint32_t length;
    char _dbg_TXBuff[100] = {0};
    va_list args;
    va_start(args, format);
    length = vsnprintf((char *)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char *)format, args);
    va_end(args);
    USART3_DMA_TX((const unsigned char *)_dbg_TXBuff, length);
}
#endif

#if USART4_DEBUG
//-----------------------------串口 4--------------------------------------------------------

u8 UART4_Rx_Buff[MAX_RX_CNT];
uint8_t UART4_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt)
{
    u8 i = 0;
    while (i < Byte_Cnt)
    {
        USART_SendData(UART4, (u8)TxBuff[i++]);
        while (USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET)
            ;
    }

    return 1;
}
static void UART4_DMA_Config(void)
{
    DMA_InitTypeDef dma_init;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);

    DMA_DeInit(DMA2_Channel5);
    DMA_DeInit(DMA2_Channel3);

    dma_init.DMA_PeripheralBaseAddr = (uint32_t) & (UART4->DR);
    dma_init.DMA_MemoryBaseAddr = (uint32_t)UART4_Rx_Buff;
    dma_init.DMA_DIR = DMA_DIR_PeripheralSRC;
    dma_init.DMA_BufferSize = MAX_RX_CNT;
    dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;
    dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
    dma_init.DMA_Mode = DMA_Mode_Normal;
    dma_init.DMA_Priority = DMA_Priority_VeryHigh;
    dma_init.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA2_Channel3, &dma_init);
    DMA_Cmd(DMA2_Channel3, ENABLE);

    USART_DMACmd(UART4, USART_DMAReq_Rx, ENABLE);
    //	USART_DMACmd(UART4, USART_DMAReq_Tx, ENABLE);
}

static void UART4_NVIC_Config(void)
{
    NVIC_InitTypeDef usart_nvic_init;

    usart_nvic_init.NVIC_IRQChannel = DMA2_Channel3_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 1;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);

    usart_nvic_init.NVIC_IRQChannel = UART4_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 7;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 4;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);
}

void UART4_Config(uint32_t BaudRate)
{
    GPIO_InitTypeDef gpio_init;
    USART_InitTypeDef usart_init;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);

    gpio_init.GPIO_Pin = GPIO_Pin_10;
    gpio_init.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &gpio_init);

    gpio_init.GPIO_Pin = GPIO_Pin_11;
    gpio_init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOC, &gpio_init);

    usart_init.USART_BaudRate = BaudRate;
    usart_init.USART_WordLength = USART_WordLength_8b;
    usart_init.USART_StopBits = USART_StopBits_1;
    usart_init.USART_Parity = USART_Parity_No;
    usart_init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(UART4, &usart_init);

    UART4_NVIC_Config();
    UART4_DMA_Config();

    USART_ITConfig(UART4, USART_IT_IDLE, ENABLE);
    USART_Cmd(UART4, ENABLE);
    USART_ClearFlag(UART4, USART_FLAG_TC);
}

/********串口4空闲中断函数*******/

void UART4_IRQHandler(void)
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)
    {
        uint8_t temp;
        temp = UART4->SR;
        temp = UART4->DR;
        //去警告
        temp = temp;
        DMA_Cmd(DMA2_Channel3, DISABLE);
        //		GetHidiData(UART4_Rx_Buff);

        xSemaphoreGiveFromISR(CountSemaphore4, &pxHigherPriorityTaskWoken); //释放计数型信号量

        DMA_SetCurrDataCounter(DMA2_Channel3, MAX_RX_CNT);
        DMA_Cmd(DMA2_Channel3, ENABLE);
        USART_ClearFlag(UART4, USART_IT_IDLE);
    }
}

/**********DMA2通道3接收中断****/

void DMA2_Channel3_IRQHandler(void)
{
    if (DMA_GetFlagStatus(DMA2_FLAG_TC3) != RESET)
    {
        DMA_ClearITPendingBit(DMA1_IT_TC3);
    }
}

/*
 *******************************************************************************
 *		DMA	printf
 *******************************************************************************
 */

//不带DMA发送
#define CMD_BUFFER_LEN 50
void u4_printf(const char *format, ...)
{

    u8 i = 0;
    uint32_t length;
    char _dbg_TXBuff[CMD_BUFFER_LEN] = {0};
    va_list args;
    taskENTER_CRITICAL(); //进入临界区
    va_start(args, format);
    length = vsnprintf((char *)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char *)format, args);
    while (i < length)
    {
        USART_SendData(UART4, (u8)_dbg_TXBuff[i++]);
        while (USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET)
            ;
    }
    taskEXIT_CRITICAL(); //退出临界区
    va_end(args);
}
#endif

/*******************************************
 *
 * 串口5  PC12   PD2
 *
 * *****************************************/

u8 UART5_Rx_Buff[MAX_RX_CNT];

uint8_t UART5_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt)
{
    u8 i = 0;
    while (i < Byte_Cnt)
    {
        USART_SendData(UART5, (u8)TxBuff[i++]);
        while (USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET)
            ;
    }

    return 1;
}

static void UART5_NVIC_Config(void)
{
    NVIC_InitTypeDef usart_nvic_init;

    usart_nvic_init.NVIC_IRQChannel = UART5_IRQn;
    usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 7;
    usart_nvic_init.NVIC_IRQChannelSubPriority = 4;
    usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&usart_nvic_init);
}

void UART5_Config(uint32_t BaudRate)
{
    GPIO_InitTypeDef gpio_init;
    USART_InitTypeDef usart_init;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD | RCC_APB2Periph_AFIO, ENABLE);

    gpio_init.GPIO_Pin = GPIO_Pin_12;
    gpio_init.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &gpio_init);

    gpio_init.GPIO_Pin = GPIO_Pin_2;
    gpio_init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOD, &gpio_init);

    usart_init.USART_BaudRate = BaudRate;
    usart_init.USART_WordLength = USART_WordLength_8b;
    usart_init.USART_StopBits = USART_StopBits_1;
    usart_init.USART_Parity = USART_Parity_No;
    usart_init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart_init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(UART5, &usart_init);

    UART5_NVIC_Config();

    USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);

    USART_ITConfig(UART5, USART_IT_IDLE, ENABLE); //添加串口空闲中断使能，请不要使用USART_IT_RXNE|USART_IT_IDLE，记住分开写两条语句
    USART_Cmd(UART5, ENABLE);
    USART_ClearFlag(UART5, USART_FLAG_TC);
}

/********串口5空闲中断函数*******/
u16 g_UART5_RecPos = 0; //存放当前串口接收数据存放的位置
void UART5_IRQHandler1(void)
{
    u8 Recive;
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (USART_GetITStatus(UART5, USART_FLAG_RXNE) != RESET)
    {
        //        uint8_t temp;

        //        temp = UART4->SR;
        //        temp = UART4->DR;

        //去警告
        //        temp = temp;
        Recive = (u8)USART_ReceiveData(UART5);
        UART5_Rx_Buff[g_UART5_RecPos++] = Recive;

        //       xSemaphoreGiveFromISR(CountSemaphore5, &pxHigherPriorityTaskWoken); //释放计数型信号量

        USART_ClearFlag(UART5, USART_IT_RXNE);
    }
    if (USART_GetFlagStatus(UART5, USART_FLAG_ORE) == SET) // 串口溢出错误
    {
        USART_ClearFlag(UART5, USART_FLAG_ORE);
    }
    if (USART_GetFlagStatus(UART5, USART_FLAG_IDLE) == SET) // 串口空闲
    {

        //用户代码
        UART5_Rx_Buff[g_UART5_RecPos] = '\0';
        //释放一个信号量，表示数据已接收;给出二值信号量 ，发送接收到新数据帧标志，供前台线程查询
        xSemaphoreGiveFromISR(CountSemaphore5, &pxHigherPriorityTaskWoken);
        USART_ReceiveData(UART5); //使用该语句清除空闲中断标志位，请不要使用USART_ClearITPendingBit(USART2, USART_IT_IDLE);该语句无法达到效果
    }
}

void UART5_IRQHandler(void)
{

    //用户代码
    u8 RecCh;
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    if (USART_GetFlagStatus(UART5, USART_FLAG_RXNE) != RESET) // 串口接收数据
    {

        //用户代码
        RecCh = (u8)USART_ReceiveData(UART5);
        UART5_Rx_Buff[g_UART5_RecPos++] = RecCh;

        USART_ClearFlag(UART5, USART_FLAG_RXNE);
    }
    if (USART_GetFlagStatus(UART5, USART_FLAG_ORE) == SET) // 串口溢出错误
    {
        USART_ClearFlag(UART5, USART_FLAG_ORE);
    }
    if (USART_GetFlagStatus(UART5, USART_FLAG_IDLE) == SET) // 串口空闲
    {

        //用户代码

        UART5_Rx_Buff[g_UART5_RecPos] = '\0';
        xSemaphoreGiveFromISR(CountSemaphore5, &pxHigherPriorityTaskWoken);

        USART_ReceiveData(UART5); //使用该语句清除空闲中断标志位，请不要使用USART_ClearITPendingBit(USART2, USART_IT_IDLE);该语句无法达到效果
    }
}

//不带DMA发送
#define CMD_BUFFER5_LEN 50
void u5_printf(const char *format, ...)
{

    u8 i = 0;
    uint32_t length;
    char _dbg_TXBuff[CMD_BUFFER5_LEN] = {0};
    va_list args;
    taskENTER_CRITICAL(); //进入临界区
    va_start(args, format);
    length = vsnprintf((char *)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char *)format, args);
    while (i < length)
    {
        USART_SendData(UART5, (u8)_dbg_TXBuff[i++]);
        while (USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET)
            ;
    }
    taskEXIT_CRITICAL(); //退出临界区
    va_end(args);
}

#if 1
#pragma import(__use_no_semihosting)
//标准库需要的支持函数
struct __FILE
{
    int handle;
};

FILE __stdout;
//定义_sys_exit()以避免使用半主机模式
void _sys_exit(int x)
{
    x = x;
}
//重定义fputc函数
int fputc(int ch, FILE *f)
{
    //	while((UART4->SR&0X40)==0);//????,??????
    //    UART4->DR = (uint8_t) ch;
    return ch;
}

#endif
