#ifndef __PS_H
#define __PS_H	 
#include "sys.h"
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#define	DATAHEAD    0xDEED //����ͷ
#define RXDATALENTH 0x0A //�������ݳ���
#define TXDATALENTH 0x0008 //�������ݳ���
#define SPSRawData  0x8006
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//�ֱ�����
#define PSB_SELECT      1
#define PSB_L3          2
#define PSB_R3          3
#define PSB_START       4
#define PSB_PAD_UP      5
#define PSB_PAD_RIGHT   6
#define PSB_PAD_DOWN    7
#define PSB_PAD_LEFT    8
#define PSB_L2          9
#define PSB_R2          10
#define PSB_L1          11
#define PSB_R1          12
#define PSB_GREEN       13
#define PSB_RED         14
#define PSB_BLUE        15
#define PSB_PINK        16
#define PSB_TRIANGLE    13
#define PSB_CIRCLE      14
#define PSB_CROSS       15


typedef struct
{
	u8  UP;
	u8	RIGHT;
	u8  DOWN;
	u8  LEFT;
	u8  L2;
	u8  R2;
	u8  L1;
	u8	R1;
	u8	GREEN;
	u8 	RED;
	u8	BLUE;
	u8  PINK;
	
	s16 PSS_LY;
	s16 PSS_LX;
	s16 PSS_RY;
	s16 PSS_RX;
	
}PSBKEY;
extern PSBKEY PSBKey;


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//���ݽ��սṹ��
typedef struct
{
	_Bool Success_Flag;	//���ճɹ���־
	_Bool Hardware_Init;//Ӳ����ʼ�����ճɹ���־
	u8    FrameLength;	//֡����
	u8    ProductType;	//��Ʒ����
	u16   CMD;			//��������
	u8    DataNum;		//�������
	s16   CheckSum;		//У����
	
}PDEALDATA_RX;
extern PDEALDATA_RX PDealData_Rx;

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
extern union PTEMPDATA{
		u16  UInTempData[15];
		s16  InTempData[15];
		u8 	 ChTempData[30];
}PTempTxData,PTempRxData;
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void GetDealPSData(u8 *data);
#endif
