
#include "./iwdg/iwdg.h"
/**********************************************************************************
 * 函数名  ：IWDG_DefaultConfiguration
 * 参    数: 无
 * 返    回：无
 * 函数功能: 初始化独立看门狗
**********************************************************************************/ 
void IWDG_init( void )
{
	//启动内部低速时钟
	RCC_LSICmd( ENABLE );
	while( RCC_GetFlagStatus( RCC_FLAG_LSIRDY ) == RESET )
	{
	}
	// 使能 预分频寄存器PR和重装载寄存器RLR可写
  IWDG_WriteAccessCmd( IWDG_WriteAccess_Enable );
	/* Configure the IWDG. */
	IWDG_WriteAccessCmd( IWDG_WriteAccess_Enable );
	//设置预分频器值
	IWDG_SetPrescaler( IWDG_Prescaler_64 );
	// 设置重装载寄存器值
	IWDG_SetReload( 625 );                   //625*64/40=1000ms
	// 把重装载寄存器的值放到计数器中
	IWDG_ReloadCounter(  );
	//使能IWDG
  IWDG_Enable(  );
	

}
void IWDG_FEED(void)
{
	
  IWDG_ReloadCounter(  );

}



























